# By-design
chrome extension for reducing the time wasted on youtube by removing the video thumbnail in both desktop &amp; mobile.


<img src="https://github.com/domdomegg/hideytthumbnails-extension/assets/112557191/3e1780fe-2610-4fb6-aa96-49300a382909"  width="160"  height="300" />

<img src="https://github.com/domdomegg/hideytthumbnails-extension/assets/112557191/648be72b-8e11-4966-a8e6-f9d00e1b93b0"  width="160"  height="300" />


<img src="https://github.com/domdomegg/hideytthumbnails-extension/assets/112557191/c7770128-4d41-4ffe-90ee-b0b5fb8fa9b7"  width="160"  height="160" />
